package RulesMining;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
*
* @author Ravalika/Keerthana
*/
public class AlgoApriori {

	
	protected int k; 

	
	protected int totalCandidateCount = 0; 
	protected long startTimestamp; 
	protected long endTimestamp; 
	private int itemsetCount;  
	private int databaseSize;
	private int minsupRelative;
	private List<int[]> database = null;
	
	
	
	protected Itemsets patterns = null;

	
	BufferedWriter writer = null; 
	
	
	public AlgoApriori() {
		
	}

	
	public Itemsets runAlgorithm(double minsup, String input, String output) throws IOException {
		
	
		if(output == null){
			writer = null;
			patterns =  new Itemsets("FREQUENT ITEMSETS");
	    }else{ 
			patterns = null;
			writer = new BufferedWriter(new FileWriter(output)); 
		}
		
		
		startTimestamp = System.currentTimeMillis();
		
		
		itemsetCount = 0;
		
		totalCandidateCount = 0;
		

		databaseSize = 0;
		Map<Integer, Integer> mapItemCount = new HashMap<Integer, Integer>(); 
		
		database = new ArrayList<int[]>();
		
		
		BufferedReader reader = new BufferedReader(new FileReader(input));
		String line;
		
		while (((line = reader.readLine()) != null)) { 
			if (line.isEmpty() == true ||
					line.charAt(0) == '#' || line.charAt(0) == '%'
							|| line.charAt(0) == '@') {
				continue;
			}
		
			String[] lineSplited = line.split("\t");
			
		
			int transaction[] = new int[lineSplited.length];
			
		
			for (int i=0; i< lineSplited.length; i++) { 
	
				Integer item = Integer.parseInt(lineSplited[i]);
	
				transaction[i] = item;
	
				Integer count = mapItemCount.get(item);
				if (count == null) {
					mapItemCount.put(item, 1);
				} else {
					mapItemCount.put(item, ++count);
				}
			}
	
			database.add(transaction);
	
			databaseSize++;
		}
	
		reader.close();
		
		this.minsupRelative = (int) Math.ceil(minsup * databaseSize);
		//System.out.println(minsup);
		//System.out.println(databaseSize);
		//System.out.println(minsupRelative);
		k = 1;
		
	
		List<Integer> frequent1 = new ArrayList<Integer>();
		for(Entry<Integer, Integer> entry : mapItemCount.entrySet()){
			if(entry.getValue() >= minsupRelative){
				frequent1.add(entry.getKey());
				saveItemsetToFile(entry.getKey(), entry.getValue());
			}
		}
		mapItemCount = null;
		
		//System.out.println(frequent1);
		Collections.sort(frequent1, new Comparator<Integer>() {
			public int compare(Integer o1, Integer o2) {
				return o1 - o2;
			}
		});
		
		
		if(frequent1.size() == 0){
		
			if(writer != null){
				writer.close();
			}
			return patterns; 
		}
		
		
		totalCandidateCount += frequent1.size();
		
		
		
		List<Itemset> level = null;
		k = 2;
		do{
			
		
			List<Itemset> candidatesK;
			
		
			if(k ==2){
				candidatesK = generateCandidate2(frequent1);
			}else{
		
				candidatesK = generateCandidateSizeK(level);
			}
			//System.out.println("candidatesK:" 
					//+ candidatesK);
		
			totalCandidateCount += candidatesK.size();

		
			for(int[] transaction: database){
		
	 loopCand:	for(Itemset candidate : candidatesK){
		
		
					int pos = 0;
		
					for(int item: transaction){
		
						if(item == candidate.itemset[pos]){
		
							pos++;
		
							if(pos == candidate.itemset.length){
		
								candidate.support++;
								continue loopCand;
							}
						}else if(item > candidate.itemset[pos]){
							continue loopCand;
						}
						
					}
				}
			}

			
			level = new ArrayList<Itemset>();
			for (Itemset candidate : candidatesK) {
				
				if (candidate.getAbsoluteSupport() >= minsupRelative) {
					
					level.add(candidate);
					
					saveItemset(candidate);
				}
			}
			
			k++;
		}while(level.isEmpty() == false);

		
		endTimestamp = System.currentTimeMillis();
		
		

		
		if(writer != null){
			writer.close();
		}
		
		return patterns;
	}
public Itemsets runAlgorithm(double minsup, String input, String output, int itemtobereplaced) throws IOException {
		
	
		if(output == null){
			writer = null;
			patterns =  new Itemsets("FREQUENT ITEMSETS");
	    }else{ 
			patterns = null;
			writer = new BufferedWriter(new FileWriter(output)); 
		}
		
		
		startTimestamp = System.currentTimeMillis();
		
		
		itemsetCount = 0;
		
		totalCandidateCount = 0;
		

		databaseSize = 0;
		Map<Integer, Integer> mapItemCount = new HashMap<Integer, Integer>(); 
		
		database = new ArrayList<int[]>();
		
		
		BufferedReader reader = new BufferedReader(new FileReader(input));
		String line;
		
		while (((line = reader.readLine()) != null)) { 
			if (line.isEmpty() == true ||
					line.charAt(0) == '#' || line.charAt(0) == '%'
							|| line.charAt(0) == '@') {
				continue;
			}
		
			String[] lineSplited = line.split("\t");
			
		
			int transaction[] = new int[lineSplited.length];
			
		int i1=0;
			for (int i=0; i< lineSplited.length; i++) { 
	
				Integer item = Integer.parseInt(lineSplited[i]);
           // System.out.println("itr "+ itemtobereplaced);  
            int n1=Integer.parseInt(lineSplited[i]);
        //    System.out.println("itr1 "+ n1); 
          //    System.out.println("itr itr1 "+ (itemtobereplaced==n1));  
	if (n1==itemtobereplaced)
        {}
        else
        {
				transaction[i1] = item;
	
				Integer count = mapItemCount.get(item);
				if (count == null) {
					mapItemCount.put(item, 1);
				} else {
					mapItemCount.put(item, ++count);
				}
	i1++;		
        }
                        }
			database.add(transaction);
	
			databaseSize++;
		}
	
		reader.close();
		
		this.minsupRelative = (int) Math.ceil(minsup * databaseSize);
		
		k = 1;
		
	
		List<Integer> frequent1 = new ArrayList<Integer>();
		for(Entry<Integer, Integer> entry : mapItemCount.entrySet()){
			if(entry.getValue() >= minsupRelative){
				frequent1.add(entry.getKey());
				saveItemsetToFile(entry.getKey(), entry.getValue());
			}
		}
		mapItemCount = null;
		
		
		Collections.sort(frequent1, new Comparator<Integer>() {
			public int compare(Integer o1, Integer o2) {
				return o1 - o2;
			}
		});
		
		
		if(frequent1.size() == 0){
		
			if(writer != null){
				writer.close();
			}
			return patterns; 
		}
		
		
		totalCandidateCount += frequent1.size();
		
		
		
		List<Itemset> level = null;
		k = 2;
		do{
			
		
			List<Itemset> candidatesK;
			
		
			if(k ==2){
				candidatesK = generateCandidate2(frequent1);
			}else{
		
				candidatesK = generateCandidateSizeK(level);
			}
			
		
			totalCandidateCount += candidatesK.size();

		
			for(int[] transaction: database){
		
	 loopCand:	for(Itemset candidate : candidatesK){
		
		
					int pos = 0;
		
					for(int item: transaction){
		
						if(item == candidate.itemset[pos]){
		
							pos++;
		
							if(pos == candidate.itemset.length){
		
								candidate.support++;
								continue loopCand;
							}
						}else if(item > candidate.itemset[pos]){
							continue loopCand;
						}
						
					}
				}
			}

			
			level = new ArrayList<Itemset>();
			for (Itemset candidate : candidatesK) {
				
	
                            if (candidate.getAbsoluteSupport() >= minsupRelative) {
					
					level.add(candidate);
					
					saveItemset(candidate);
				}
			}
			
			k++;
		}while(level.isEmpty() == false);

		
		endTimestamp = System.currentTimeMillis();
		
		

		
		if(writer != null){
			writer.close();
		}
		
		return patterns;
	}
	
	public int getDatabaseSize() {
		return databaseSize;
	}

	
	private List<Itemset> generateCandidate2(List<Integer> frequent1) {
		List<Itemset> candidates = new ArrayList<Itemset>();
		
		
		for (int i = 0; i < frequent1.size(); i++) {
			Integer item1 = frequent1.get(i);
			for (int j = i + 1; j < frequent1.size(); j++) {
				Integer item2 = frequent1.get(j);

				
				candidates.add(new Itemset(new int []{item1, item2}));
			}
		}
		return candidates;
	}

	
	protected List<Itemset> generateCandidateSizeK(List<Itemset> levelK_1) {
		
		List<Itemset> candidates = new ArrayList<Itemset>();

		
		loop1: for (int i = 0; i < levelK_1.size(); i++) {
			int[] itemset1 = levelK_1.get(i).itemset;
			loop2: for (int j = i + 1; j < levelK_1.size(); j++) {
				int[] itemset2 = levelK_1.get(j).itemset;

				
				for (int k = 0; k < itemset1.length; k++) {
					
					if (k == itemset1.length - 1) {
						
						if (itemset1[k] >= itemset2[k]) {
							continue loop1;
						}
					}
					
					else if (itemset1[k] < itemset2[k]) {
						continue loop2; 
					} else if (itemset1[k] > itemset2[k]) {
						continue loop1; 
					}
				}

				
				int newItemset[] = new int[itemset1.length+1];
				System.arraycopy(itemset1, 0, newItemset, 0, itemset1.length);
				newItemset[itemset1.length] = itemset2[itemset2.length -1];

				
				if (allSubsetsOfSizeK_1AreFrequent(newItemset, levelK_1)) {
					candidates.add(new Itemset(newItemset));
				}
			}
		}
		return candidates; 
	}

	
	protected boolean allSubsetsOfSizeK_1AreFrequent(int[] candidate, List<Itemset> levelK_1) {
		
		for(int posRemoved=0; posRemoved< candidate.length; posRemoved++){

		
	        int first = 0;
	        int last = levelK_1.size() - 1;
	       
	        
	        boolean found = false;
	        
	        while( first <= last )
	        {
	        	int middle = ( first + last ) / 2;

	            if(sameAs(levelK_1.get(middle), candidate, posRemoved)  < 0 ){
	            	first = middle + 1;
	            }
	            else if(sameAs(levelK_1.get(middle), candidate, posRemoved)  > 0 ){
	            	last = middle - 1; 
	            }
	            else{
	            	found = true; 
	                break;
	            }
	        }

			if(found == false){ 
				return false;
			}
		}
		return true;
	}

	

private int sameAs(Itemset itemset, int [] candidate, int posRemoved) {
		
		int j=0;
		
		for(int i=0; i<itemset.itemset.length; i++){
		
			if(j == posRemoved){
				j++;
			}
		
			if(itemset.itemset[i] == candidate[j]){
				j++;
			}else if (itemset.itemset[i] > candidate[j]){
				return 1;
			}else{
				return -1;
			}
		}
		return 0;
	}
	

	 void saveItemset(Itemset itemset) throws IOException {
		itemsetCount++;
		
		
		if(writer != null){
			writer.write(itemset.toString() + " #SUP: "
					+ itemset.getAbsoluteSupport());
			writer.newLine();
		}
		else{
			patterns.addItemset(itemset, itemset.size());
		}
	}
	
	 void saveItemsetToFile(Integer item, Integer support) throws IOException {
		itemsetCount++;
		
		
		if(writer != null){
			writer.write(item + " #SUP: " + support);
			writer.newLine();
                        
		}
		else{
			Itemset itemset = new Itemset(item);
			itemset.setAbsoluteSupport(support);
			patterns.addItemset(itemset, 1);
		}
	}
	
	
	public void printStats() {
		System.out.println("=============  APRIORI - STATS =============");
		System.out.println(" Candidates count : " + totalCandidateCount);
		System.out.println(" The algorithm stopped at size " + (k - 1)
				+ ", because there is no candidate");
		System.out.println(" Frequent itemsets count : " + itemsetCount);
		//System.out.println(" Maximum memory usage : " + MemoryLogger.getInstance().getMaxMemory() + " mb");
		System.out.println(" Total time ~ " + (endTimestamp - startTimestamp) + " ms");
		System.out.println("===================================================");
	}
}
