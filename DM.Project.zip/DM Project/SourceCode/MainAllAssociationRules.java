
package RulesMining;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
//import java.util.ArrayList;
//import java.util.List;

public class MainAllAssociationRules {

	public static void main(String [] arg) throws FileNotFoundException, IOException{

		String input = "D:/MS/data.txt"; ////fileToPath("C:\\input.txt");
		
//double securitymargin=0.0;
		double minsupp = 0.1;
	//	double newminsupp = minsupp-securitymargin;
		String output = null;

		double  minconf = 0.20;
                int databaseSize;
                AlgoApriori apriori = new AlgoApriori();
		Itemsets patterns = apriori.runAlgorithm(minsupp, input, output);
               // Itemsets p1;
                databaseSize=apriori.getDatabaseSize();
              //  System.out.println("patterns Count :"+patterns.getItemsetsCount());
            //    System.out.println("level Count :"+patterns.getLevelsCount());
               System.out.println("Before Removal of item");
                        patterns.printItemsets(1);//(patterns.getLevelsCount()-1);
                        Algoaprioriasso algoAgrawal = new Algoaprioriasso();
                
		Rules rules = algoAgrawal.runAlgorithm(patterns, null, databaseSize, minconf);
		rules.printRules(databaseSize);
              

	}
	
	public static String fileToPath(String filename) throws UnsupportedEncodingException{
		URL url = MainAllAssociationRules.class.getResource(filename);
		 return java.net.URLDecoder.decode(url.getPath(),"UTF-8");
	}
}
