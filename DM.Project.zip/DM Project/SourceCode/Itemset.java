package RulesMining;

/**
*
* @author Ravalika/Keerthana
*/
public class Itemset extends AbstractOrderedItemset{

	public int[] itemset; 


	public int support = 0; 
	
	public int[] getItems() {
		return itemset;
	}
	
	public Itemset(){
		itemset = new int[]{};
	}
	
	public Itemset(int item){
		itemset = new int[]{item};
	}

	public Itemset(int [] items){
		this.itemset = items;
	}
	
	public int getAbsoluteSupport(){
		return support;
	}
	
	public int size() {
		return itemset.length;
	}

	public Integer get(int position) {
		return itemset[position];
	}

	public void setAbsoluteSupport(Integer support) {
		this.support = support;
	}

	public void increaseTransactionCount() {
		this.support++;
	}



	public Itemset cloneItemSetMinusOneItem(Integer itemsetToRemove) {

		int[] newItemset = new int[itemset.length -1];
		int i=0;

		for(int j =0; j < itemset.length; j++){

			if(itemset[j] != itemsetToRemove){
				newItemset[i++] = itemset[j];
			}
		}
		return new Itemset(newItemset); // return the copy
	}

	public Itemset cloneItemSetMinusAnItemset(Itemset itemsetToNotKeep) {

		int[] newItemset = new int[itemset.length - itemsetToNotKeep.size()];
		int i=0;

		for(int j =0; j < itemset.length; j++){

			if(itemsetToNotKeep.contains(itemset[j]) == false){
				newItemset[i++] = itemset[j];
			}
		}
		return new Itemset(newItemset); // return the copy
	}

}
