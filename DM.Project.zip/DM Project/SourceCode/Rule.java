package RulesMining;

/**
*
* @author Ravalika/Keerthana
*/

public class Rule {
	private Itemset itemset1; // antecedent
	private Itemset itemset2; // consequent
	private int transactionCount; // relative support
	private double confidence; // confidence of the rule
	private double lift; // lift of the rule

	public Rule(Itemset itemset1, Itemset itemset2,
			int transactionCount, double confidence, double lift) {
		this.itemset1 = itemset1;
		this.itemset2 = itemset2;
		this.transactionCount = transactionCount;
		this.confidence = confidence;
		this.lift = lift;
	}

	public double getRelativeSupport(int databaseSize) {
		return ((double) transactionCount) / ((double) databaseSize);
	}

	public int getAbsoluteSupport() {
		return transactionCount;
	}

	public double getConfidence() {
		return confidence;
	}

	public double getLift() {
		return lift;
	}

	public void print() {
		System.out.println(toString());
	}

	public String toString() {
		return itemset1.toString() + " ==> " + itemset2.toString();
	}

	public Itemset getItemset1() {
		return itemset1;
	}

	public Itemset getItemset2() {
		return itemset2;
	}
}
