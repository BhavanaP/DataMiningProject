package RulesMining;

import java.util.ArrayList;
import java.util.List;

/**
*
* @author Ravalika/Keerthana
*/
public class Itemsets {
	private final List<List<Itemset>> levels = new ArrayList<List<Itemset>>();

	private int itemsetsCount = 0;
	public int levelCount = 0;
	private final String name;

	public Itemsets(String name) {
		this.name = name;
		levels.add(new ArrayList<Itemset>()); // We create an empty level 0 by
												// default.
	}

	public void printItemsets(int nbObject) {
		//System.out.println(" ------- " + name + " -------");
		int patternCount = 0;
		int levelCount = 0;

		for (List<Itemset> level : levels) {

			//System.out.println("  L" + levelCount + " ");

			for (Itemset itemset : level) {

				//System.out.print("  pattern " + patternCount + ":  ");
				itemset.print();

				//System.out.print("support :  "
						//+ itemset.getRelativeSupportAsString(nbObject));
				patternCount++;
				//System.out.println("");
			}
		}
		levelCount++;

		//System.out.println(" --------------------------------");
	}

	public List<Itemset> getItemsets(int nbObject) {
		//System.out.println(" ------- " + name + " -------");
		int patternCount = 0;
		levelCount = 0;
		boolean found = false;
		List<Itemset> level1 = null;
		for (List<Itemset> level : levels) {
			if (levelCount == nbObject) {
				found = true;
				return level;
			} else {
				levelCount++;
			}
		}
		return level1;
	}

	public void addItemset(Itemset itemset, int k) {
		while (levels.size() <= k) {
			levels.add(new ArrayList<Itemset>());
		}
		levels.get(k).add(itemset);
		itemsetsCount++;
	}

	public List<List<Itemset>> getLevels() {
		return levels;
	}

	public int getItemsetsCount() {
		return itemsetsCount;
	}

	public int getLevelsCount() {
		levelCount = 0;

		List<Itemset> level1 = null;
		for (List<Itemset> level : levels) {
			levelCount++;
		}

		return levelCount;
	}
}
