package RulesMining;

/**
*
* @author Ravalika/Keerthana
*/

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashSet;
import java.util.Set;





public class Algoaprioriasso {
	

	private Itemsets patterns;
	
	private Rules rules;
	

	BufferedWriter writer = null;
	

	long startTimestamp = 0; 
	long endTimeStamp = 0;   
	private int ruleCount = 0;
	private int databaseSize = 0; 
	
	
	private double minconf;
	private double minlift;
	private boolean usingLift = true;
	
	public Algoaprioriasso(){
		
	}

	
	public Rules runAlgorithm(Itemsets patterns, String output, int databaseSize, double minconf) throws IOException {
		
		this.minconf = minconf;
		this.minlift = 0;
		usingLift = false;
		
		
		return runAlgorithm(patterns, output, databaseSize);
	}

	
	public Rules runAlgorithm(Itemsets patterns, String output, int databaseSize, double minconf,
			double minlift) throws IOException {
		
		this.minconf = minconf;
		this.minlift = minlift;
		usingLift = true;
		
		
		return runAlgorithm(patterns, output, databaseSize);
	}

	private Rules runAlgorithm(Itemsets patterns, String output, int databaseSize)
			throws IOException {
		
		
		if(output == null){
			writer = null;
			rules =  new Rules("ASSOCIATION RULES");
	    }else{ 
	    
	    	rules = null;
			writer = new BufferedWriter(new FileWriter(output)); 
		}

		
		this.databaseSize = databaseSize;
		
		
		startTimestamp = System.currentTimeMillis();
		
		ruleCount = 0;
		
		this.patterns = patterns;

		
		for (int k = 2; k < patterns.getLevels().size(); k++) {
			for (Itemset lk : patterns.getLevels().get(k)) {
				
				Set<Itemset> H1 = new HashSet<Itemset>();
				for (Itemset itemsetSize1 : patterns.getLevels().get(1)) {
					if (lk.contains(itemsetSize1.getItems()[0])) {
						H1.add(itemsetSize1);
					}
				}

								Set<Itemset> H1_for_recursion = new HashSet<Itemset>();
				
				for (Itemset hm_P_1 : H1) {
					Itemset itemset_Lk_minus_hm_P_1 = (Itemset)lk
							.cloneItemSetMinusAnItemset(hm_P_1);
				
					calculateSupport(itemset_Lk_minus_hm_P_1); 

																// OPTIMIZED ?
																// OR DONE
																// ANOTHER WAY ?
				
					double conf = ((double) lk.getAbsoluteSupport())
							/ ((double) itemset_Lk_minus_hm_P_1
									.getAbsoluteSupport());


					if(conf < minconf){
						continue;
					}
					
					double lift =0;

					if(usingLift){

						calculateSupport(hm_P_1);  // if we want to calculate the lift, we need to add this.

						double term1 = ((double)lk.getAbsoluteSupport()) /databaseSize;
						double term2 = ((double)itemset_Lk_minus_hm_P_1.getAbsoluteSupport()) /databaseSize;
						double term3 = ((double)hm_P_1.getAbsoluteSupport() / databaseSize);
						lift = term1 / (term2 * term3);
						if(lift < minlift){
							continue;
						}
					}
					

					Rule rule = new Rule(itemset_Lk_minus_hm_P_1, hm_P_1, lk.getAbsoluteSupport(), conf, lift);

					saveRule(rule);

					H1_for_recursion.add(hm_P_1);
					
				}



				apGenrules(k, 1, lk, H1_for_recursion);
			}
		}


		if(writer != null){
			writer.close();
		}

		endTimeStamp = System.currentTimeMillis();
		
		return rules;
	}

	private void saveRule(Rule rule) throws IOException {
		ruleCount++;
		
		
		if(writer != null){
			StringBuffer buffer = new StringBuffer();
		
			for (int i = 0; i < rule.getItemset1().size(); i++) {
				buffer.append(rule.getItemset1().get(i));
				if (i != rule.getItemset1().size() - 1) {
					buffer.append(" ");
				}
			}
		
			buffer.append(" ==> ");
		
			for (int i = 0; i < rule.getItemset2().size(); i++) {
				buffer.append(rule.getItemset2().get(i));
				if (i != rule.getItemset2().size() - 1) {
					buffer.append(" ");
				}
			}
		
			buffer.append(" #SUP: ");
		
			buffer.append(rule.getAbsoluteSupport());
		
			buffer.append(" #CONF: ");
		
			buffer.append(doubleToString(rule.getConfidence()));
			if(usingLift){
				buffer.append(" #LIFT: ");
				buffer.append(doubleToString(rule.getLift()));
			}
			
			writer.write(buffer.toString());
			writer.newLine();
			writer.flush();
		}

		else{
			rules.addRule(rule);
		}
	}

	private void apGenrules(int k, int m, Itemset lk, Set<Itemset> Hm)
			throws IOException {

		if (k > m + 1) {
			Set<Itemset> Hm_plus_1 = generateCandidateSizeK(Hm);
			Set<Itemset> Hm_plus_1_for_recursion = new HashSet<Itemset>();

			for (Itemset hm_P_1 : Hm_plus_1) {
				Itemset itemset_Lk_minus_hm_P_1 = (Itemset) lk
						.cloneItemSetMinusAnItemset(hm_P_1);

				calculateSupport(itemset_Lk_minus_hm_P_1); 
															// ANOTHER WAY ?
															// IT COULD PERHAPS
															// BE IMPROVED....
				
				
				double conf = ((double) lk.getAbsoluteSupport())
						/ ((double) itemset_Lk_minus_hm_P_1
								.getAbsoluteSupport());

				if(conf < minconf){
					continue;
				}
				
				double lift =0;
				
				if(usingLift){
				
					calculateSupport(hm_P_1);  
				
					double term1 = ((double)lk.getAbsoluteSupport()) /databaseSize;
					double term2 = ((double)itemset_Lk_minus_hm_P_1.getAbsoluteSupport()) /databaseSize;
					
					 lift = term1 / (term2 * ((double)hm_P_1.getAbsoluteSupport() / databaseSize));
					if(lift < minlift){
						continue;
					}
				}
				
				Rule rule = new Rule(itemset_Lk_minus_hm_P_1, hm_P_1, lk.getAbsoluteSupport(), conf, lift);
				saveRule(rule);

				Hm_plus_1_for_recursion.add(hm_P_1);
			}

			apGenrules(k, m + 1, lk, Hm_plus_1_for_recursion);
		}
	}

	private void calculateSupport(Itemset itemset_Lk_minus_hm_P_1) {

		for (Itemset itemset : patterns.getLevels().get(
				itemset_Lk_minus_hm_P_1.size())) {
			if (itemset.isEqualTo(itemset_Lk_minus_hm_P_1)) {

				itemset_Lk_minus_hm_P_1.setAbsoluteSupport(itemset
						.getAbsoluteSupport());
				return;
			}
		}
	}

	protected Set<Itemset> generateCandidateSizeK(Set<Itemset> levelK_1) {
		Set<Itemset> candidates = new HashSet<Itemset>();


		for (Itemset itemset1 : levelK_1) {
			for (Itemset itemset2 : levelK_1) {
				Integer missing = itemset1.allTheSameExceptLastItem(itemset2);
				if (missing != null) {
					int newItemset[] = new int[itemset1.size()+1];
					System.arraycopy(itemset1.itemset, 0, newItemset, 0, itemset1.size());
					newItemset[itemset1.size()] = itemset2.getItems()[itemset2.size() -1];
					Itemset candidate = new Itemset(newItemset);

					if (allSubsetsOfSizeK_1AreFrequent(candidate, levelK_1)) {
						candidates.add(candidate);
					}
				}
			}
		}
		return candidates;
	}

	protected boolean allSubsetsOfSizeK_1AreFrequent(Itemset candidate,
			Set<Itemset> levelK_1) {
		if (candidate.size() == 1) {
			return true;
		}
		for (Integer item : candidate.getItems()) {
			Itemset subset = (Itemset)candidate.cloneItemSetMinusOneItem(item);
			
			boolean found = false;

			for (Itemset itemset : levelK_1) {

				if (itemset.isEqualTo(subset)) {
					found = true;
					break;
				}
			}

			if (found == false) {
				return false;
			}
		}

		return true;
	}

	public void printStats() {
		System.out
				.println("=============  ASSOCIATION RULE GENERATION - STATS =============");
		System.out.println(" Number of association rules generated : "
				+ ruleCount);
		System.out.println(" Total time ~ " + (endTimeStamp - startTimestamp)
				+ " ms");
		System.out
				.println("===================================================");
	}
	
	String doubleToString(double value) {

		DecimalFormat format = new DecimalFormat();
		format.setMinimumFractionDigits(0); 
		format.setMaximumFractionDigits(5); 
		return format.format(value);
	}
	
	
	private void saveTextToFile(String text) throws IOException{
		writer.write(text);
	}
	
	
	
	public void saveStatsToFile() throws IOException {
		saveTextToFile("=============  ASSOCIATION RULE GENERATION - STATS =============\n");
		saveTextToFile(" Number of itemsets generated : "
				+ patterns.getItemsetsCount() + "\n");
		saveTextToFile(" Number of association rules generated : "
				+ ruleCount + "\n");
		saveTextToFile(" Total time ~ " + (endTimeStamp - startTimestamp)
				+ " ms\n");
		saveTextToFile("===================================================\n");
	}
}
