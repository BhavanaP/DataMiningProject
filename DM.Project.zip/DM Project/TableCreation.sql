
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';
--
-- Database: `dm`
--
DROP SCHEMA IF EXISTS `DM1` ;
CREATE SCHEMA IF NOT EXISTS `DM1` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `DM1` ;

-- --------------------------------------------------------

--
-- Table structure for table `codeforwords`
--

CREATE TABLE IF NOT EXISTS `codeforwords` (
  `colname` varchar(25) NOT NULL,
  `colvalue` varchar(25) NOT NULL,
  `code` int(11) NOT NULL,
  PRIMARY KEY (`colname`,`colvalue`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


--
-- Table structure for table `colnamesvalues`
--

CREATE TABLE IF NOT EXISTS `colnamesvalues` (
  `colname` varchar(25) NOT NULL,
  `colvalue` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `Username` varchar(25) NOT NULL,
  `Password` varchar(8) NOT NULL,
  PRIMARY KEY (`Username`,`Password`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Username`, `Password`) VALUES
('hr', 'hr');

-- --------------------------------------------------------
